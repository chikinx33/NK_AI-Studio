#!/usr/bin/env python3
"""HWPX 템플릿 자체 검사 — 한컴에서 열어보기 전에 잡을 수 있는 것을 전부 잡는다.

v2 에서 두 번 놓친 것을 고정한다:
  ① charPr height 단위 오류(900pt 글자) → 한 글자가 페이지를 덮음
  ② 헤더 스냅샷 시점 오류로 borderFill 유실 → 본문이 없는 id 를 참조해 파일이 깨짐
"""
import re
import sys
import zipfile

path = sys.argv[1] if len(sys.argv) > 1 else "quote-standard/template.hwpx"
z = zipfile.ZipFile(path)
header = z.read("Contents/header.xml").decode("utf-8")
body = z.read("Contents/section0.xml").decode("utf-8")
fail = []


def ids_of(xml, tag):
    out = set()
    for m in re.finditer(r"<hh:%s\b[^>]*>" % tag, xml):
        got = re.search(r'\bid="(\d+)"', m.group(0))
        if got:
            out.add(got.group(1))
    return out


def refs_of(xml, attr):
    return set(re.findall(r'\b%s="(\d+)"' % attr, xml))


print(f"검사 대상: {path}")

# 1. 참조 무결성 — 본문이 가리키는 스타일 id 가 헤더에 전부 있는가
for attr, tag, label in [
    ("charPrIDRef", "charPr", "글자 모양"),
    ("paraPrIDRef", "paraPr", "문단 모양"),
    ("borderFillIDRef", "borderFill", "테두리·음영"),
]:
    have, want = ids_of(header, tag), refs_of(body, attr)
    missing = sorted(want - have, key=int)
    status = "OK" if not missing else f"★없는 id {missing}"
    print(f" 1. {label:<10} 헤더 {len(have)}개 / 본문참조 {len(want)}개 → {status}")
    if missing:
        fail.append(f"{label}: 헤더에 없는 id {missing} 를 본문이 참조")

# 2. 글자 크기 — 6~25pt 밖이면 단위를 잘못 넣은 것
sizes = []
for m in re.finditer(r"<hh:charPr\b[^>]*>", header):
    i = re.search(r'\bid="(\d+)"', m.group(0))
    h = re.search(r'\bheight="(\d+)"', m.group(0))
    if i and h:
        sizes.append((i.group(1), int(h.group(1))))
bad = [(i, h) for i, h in sizes if not (600 <= h <= 2500)]
print(f" 2. 글자 크기      {len(sizes)}개 중 범위 밖 {len(bad)}개 →", "OK" if not bad else
      f"★{[(i, f'{h/100}pt') for i, h in bad]}")
if bad:
    fail.append(f"글자 크기가 6~25pt 밖: {[(i, h/100) for i, h in bad]}")

# 3. 정렬 — CENTER/RIGHT paraPr 가 실제로 존재하는가
aligns = {}
for m in re.finditer(r'<hh:paraPr\b[^>]*\bid="(\d+)".*?<hh:align\b[^>]*horizontal="(\w+)"', header, re.S):
    aligns.setdefault(m.group(2), []).append(m.group(1))
print(" 3. 정렬 종류      ", {k: len(v) for k, v in aligns.items()},
      "→", "OK" if {"CENTER", "RIGHT"} <= set(aligns) else "★CENTER/RIGHT 없음")
if not {"CENTER", "RIGHT"} <= set(aligns):
    fail.append("CENTER/RIGHT 문단 모양이 없어 전부 좌측 정렬로 렌더된다")

# 4. 자리표시자 — 쪼개짐 없이 온전한가
texts = re.findall(r"<hp:t[^>]*>(.*?)</hp:t>", body, re.S)
split = [t for t in texts if "{{" in t and t.count("{{") != t.count("}}")]
tags = set(re.findall(r"\{\{([a-zA-Z0-9_.]+)\}\}", body))
print(f" 4. 자리표시자     {len(tags)}종 / 쪼개짐 {len(split)}개 →", "OK" if not split else "★쪼개짐")
if split:
    fail.append(f"자리표시자가 쪼개진 노드 {len(split)}개")

# 5. 반복 표 행 수
for prefix, expect in [("row", 30), ("sum", 6), ("info", 8), ("term", 8)]:
    got = len(re.findall(r"\{\{" + prefix + r"\.(?:no|label)\}\}", body))
    print(f" 5. {{{{{prefix}.}}}} 행 {got}/{expect} →", "OK" if got == expect else "★불일치")
    if got != expect:
        fail.append(f"{prefix} 반복 행 {got}개 (기대 {expect})")

# 6. ZIP 규약
first = z.infolist()[0]
ok_mime = first.filename == "mimetype" and first.compress_type == zipfile.ZIP_STORED
print(" 6. mimetype 선두·STORED →", "OK" if ok_mime else "★위반")
if not ok_mime:
    fail.append("mimetype 이 첫 엔트리가 아니거나 압축돼 있다")

# 7. 네임스페이스 오염
print(" 7. ns0 오염       →", "OK" if "ns0:" not in body and "ns0:" not in header else "★오염")
if "ns0:" in body or "ns0:" in header:
    fail.append("ns0: 접두어 오염 — 네임스페이스가 재작성됐다")

# 8. 빈 표
zero = re.findall(r'<hp:tbl\b[^>]*rowCnt="0"', body)
print(" 8. 행 0개인 표    →", "OK" if not zero else f"★{len(zero)}개 (한컴이 파일을 거부한다)")
if zero:
    fail.append(f"행이 0개인 표 {len(zero)}개")

print()
if fail:
    print("실패", len(fail), "건:")
    for f in fail:
        print("  -", f)
    sys.exit(1)
print("전 항목 통과")
