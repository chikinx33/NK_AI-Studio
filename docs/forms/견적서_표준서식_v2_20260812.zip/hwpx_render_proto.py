#!/usr/bin/env python3
"""HWPX 렌더러 프로토타입 — 설계서 §6.2 알고리즘 검증용.

python-hwpx API를 쓰지 않고 zip + XML 조작만으로 처리한다.
Workers(TypeScript) 렌더러가 그대로 옮겨 쓸 수 있는 절차를 증명하는 것이 목적.
"""
import json, re, sys, zipfile, io
import xml.etree.ElementTree as ET

HP = "http://www.hancom.co.kr/hwpml/2011/paragraph"
ET.register_namespace("hp", HP)
Q = lambda tag: f"{{{HP}}}{tag}"


def deep_get(obj, path):
    cur = obj
    for k in path.split("."):
        if isinstance(cur, dict):
            cur = cur.get(k)
        else:
            return None
        if cur is None:
            return None
    return cur


def subst_text(s, data):
    """<hp:t> 텍스트 하나를 치환. 매칭 실패 시 빈 문자열."""
    def rep(m):
        v = deep_get(data, m.group(1))
        return "" if v is None else str(v)
    return re.sub(r"\{\{([a-zA-Z0-9_.]+)\}\}", rep, s)


def merge_runs(para):
    """같은 <hp:run> 안의 인접 <hp:t>를 하나로 합친다 (설계서 §6.2 2단계).
    한글이 서식 경계에서 텍스트를 쪼갠 경우를 복구한다."""
    for run in para.iter(Q("run")):
        ts = [c for c in list(run) if c.tag == Q("t")]
        if len(ts) <= 1:
            continue
        first = ts[0]
        first.text = "".join((t.text or "") for t in ts)
        for t in ts[1:]:
            run.remove(t)


def row_prefix(tr):
    """이 행이 어떤 반복 접두어에 속하는지. 없으면 None."""
    txt = "".join(t.text or "" for t in tr.iter(Q("t")))
    m = re.search(r"\{\{([a-zA-Z0-9_]+)\.", txt)
    return m.group(1) if m else None


def render(template_path, data, out_path, repeaters):
    zin = zipfile.ZipFile(template_path)
    entries = {n: zin.read(n) for n in zin.namelist()}
    order = zin.namelist()
    zin.close()

    changed = []
    for name in order:
        if not re.search(r"section\d+\.xml$", name):
            continue
        root = ET.fromstring(entries[name].decode("utf-8"))

        # 2단계: run 병합
        for p in root.iter(Q("p")):
            merge_runs(p)

        # 4단계: 반복 표 처리
        for tbl in root.iter(Q("tbl")):
            trs = [c for c in list(tbl) if c.tag == Q("tr")]
            groups = {}
            for tr in trs:
                pre = row_prefix(tr)
                if pre in repeaters:
                    groups.setdefault(pre, []).append(tr)
            for pre, rows in groups.items():
                arr = deep_get(data, repeaters[pre]) or []
                if len(arr) > len(rows):
                    raise ValueError(
                        f"'{pre}' 항목이 {len(arr)}개인데 서식의 행은 {len(rows)}개입니다. "
                        f"서식의 행을 늘리거나 항목을 줄여 주세요."
                    )
                for i, tr in enumerate(rows):
                    if i < len(arr):
                        item = arr[i]
                        for t in tr.iter(Q("t")):
                            if t.text and "{{" in t.text:
                                t.text = re.sub(
                                    r"\{\{" + pre + r"\.([a-zA-Z0-9_]+)\}\}",
                                    lambda m: str(item.get(m.group(1), "") or ""),
                                    t.text,
                                )
                    else:
                        tbl.remove(tr)          # 미사용 행 삭제
            # rowCnt 갱신 (누락하면 한글이 파일을 거부한다)
            if groups:
                remaining = [c for c in list(tbl) if c.tag == Q("tr")]
                tbl.set("rowCnt", str(len(remaining)))
                # 행 인덱스(rowAddr) 재부여
                for ri, tr in enumerate(remaining):
                    for tc in tr.iter(Q("tc")):
                        addr = tc.find(Q("cellAddr"))
                        if addr is not None:
                            addr.set("rowAddr", str(ri))

        # 3단계: 남은 단순 필드 치환
        for t in root.iter(Q("t")):
            if t.text and "{{" in t.text:
                t.text = subst_text(t.text, data)

        entries[name] = ET.tostring(root, encoding="utf-8", xml_declaration=True)
        changed.append(name)

    # 6단계: rezip — mimetype은 STORED로 맨 앞
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as zout:
        if "mimetype" in entries:
            zi = zipfile.ZipInfo("mimetype")
            zi.compress_type = zipfile.ZIP_STORED
            zout.writestr(zi, entries["mimetype"])
        for n in order:
            if n == "mimetype":
                continue
            zout.writestr(n, entries[n])
    open(out_path, "wb").write(buf.getvalue())
    return changed


if __name__ == "__main__":
    data = json.load(open(sys.argv[1] if len(sys.argv) > 1 else "_sample.json"))
    out = sys.argv[2] if len(sys.argv) > 2 else "_test_filled.hwpx"
    reps = {"row": "totals.rows", "sum": "totals.summaryRows",
            "info": "totals.infoRows", "term": "totals.termRows"}
    changed = render("quote-standard/template.hwpx", data, out, reps)
    print("rendered:", out, "| sections:", changed)
