#!/usr/bin/env python3
# 견적서 표준 템플릿 (HWPX) v2 — 서식 포함본
# v1 실패 원인: 표 구조만 만들고 charPr(글자)·paraPr(정렬)·borderFill(음영/테두리)을
#              하나도 지정하지 않아 한컴에서 전부 기본값(좌측정렬·큰 글자)으로 렌더됐다.
import copy
import xml.etree.ElementTree as ET
from hwpx.document import HwpxDocument

OUT = "/home/claude/forms/quote-standard/template.hwpx"
A4_W, A4_H, MARGIN = 59528, 84188, 4252
CONTENT_W = A4_W - MARGIN * 2                      # 51024
MAX_ROW, MAX_SUM, MAX_INFO, MAX_TERM = 30, 6, 8, 8

doc = HwpxDocument.new()
doc.page.set_size(width=A4_W, height=A4_H, orientation="NARROWLY")
doc.page.set_margins(left=MARGIN, right=MARGIN, top=MARGIN, bottom=MARGIN, header=0, footer=0)

# ── 글자 모양 (size 단위 = 1/100 pt) ─────────────────────────────────────────
FONT = "맑은 고딕"
CP = {
    "title": doc.styles.ensure_run(size=2000, bold=True, font=FONT, letter_spacing=30),
    "head":  doc.styles.ensure_run(size=900,  bold=True, font=FONT),
    "body":  doc.styles.ensure_run(size=900,  font=FONT),
    "small": doc.styles.ensure_run(size=800,  font=FONT, color="#666666"),
    "big":   doc.styles.ensure_run(size=1200, bold=True, font=FONT),
    "name":  doc.styles.ensure_run(size=1000, bold=True, font=FONT),
}
print("charPr:", CP)

# ── 문단 모양 — CENTER/RIGHT 가 기본 문서에 없어서 복제해 만든다 ─────────────
import io, zipfile
tmp = doc.to_bytes()
header_xml = zipfile.ZipFile(io.BytesIO(tmp)).read("Contents/header.xml").decode("utf-8")


def clone_align(align_value: str) -> str:
    """paraPr 0 을 복제해 정렬만 바꾼 새 paraPr 를 만들고 id 를 돌려준다."""
    global header_xml
    m = ET.fromstring(header_xml)
    lst = None
    for node in m.iter():
        if node.tag.endswith("paraProperties"):
            lst = node
            break
    if lst is None:
        raise RuntimeError("paraPrList 를 찾지 못했습니다.")
    items = [c for c in lst if c.tag.endswith("paraPr")]
    new_id = str(max(int(c.get("id")) for c in items) + 1)
    clone = copy.deepcopy(items[0])
    clone.set("id", new_id)
    for child in clone:
        if child.tag.endswith("align"):
            child.set("horizontal", align_value)
            break
    lst.append(clone)
    lst.set("itemCnt", str(len(items) + 1))
    header_xml = ET.tostring(m, encoding="unicode")
    return new_id


PP = {"left": "0", "center": clone_align("CENTER"), "right": clone_align("RIGHT")}
print("paraPr:", PP)

# ── 테두리·음영 ──────────────────────────────────────────────────────────────
BF_HEAD = doc.styles.ensure_border_fill(fill_color="#EDF1F7", border_color="#7A7A7A",
                                        active_borders=["left", "right", "top", "bottom"])
BF_CELL = doc.styles.ensure_border_fill(border_color="#7A7A7A",
                                        active_borders=["left", "right", "top", "bottom"])
BF_NONE = doc.styles.ensure_border_fill(border_color="#FFFFFF", active_borders=[])
print("borderFill: head", BF_HEAD, "cell", BF_CELL, "none", BF_NONE)


# ── 헬퍼 ─────────────────────────────────────────────────────────────────────
def style_cell(table, r, c, cp="body", pp="left", bf=None):
    cell = table.cell(r, c)
    for p in cell.paragraphs:
        p.para_pr_id_ref = PP[pp]
        for run in p.runs:
            run.char_pr_id_ref = CP[cp]
    if bf is not None:
        table.set_cell_border_fill(r, c, bf)


def para(text="", cp="body", pp="left"):
    p = doc.add_paragraph(text)
    p.para_pr_id_ref = PP[pp]
    for run in p.runs:
        run.char_pr_id_ref = CP[cp]
    return p


def table(rows, cols, widths):
    t = doc.add_table(rows, cols, width=CONTENT_W, border_fill_id_ref=BF_CELL)
    t.set_column_widths(widths)
    return t


# ── 1. 제목 ──────────────────────────────────────────────────────────────────
para("견   적   서", "title", "center")
para("")

# ── 2. 문서번호 / 발행일 (테두리 없음) ───────────────────────────────────────
meta = table(1, 2, [26000, CONTENT_W - 26000])
meta.set_cell_text(0, 0, "{{title}}")
meta.set_cell_text(0, 1, "No.  {{docNo}}          발행일  {{issuedAt}}")
style_cell(meta, 0, 0, "name", "left", BF_NONE)
style_cell(meta, 0, 1, "body", "right", BF_NONE)
para("")

# ── 3. 공급받는자 / 공급자 ───────────────────────────────────────────────────
pw = [21000, CONTENT_W - 21000]
party = table(2, 2, pw)
party.set_cell_text(0, 0, "공 급 받 는 자")
party.set_cell_text(0, 1, "공  급  자")
party.set_cell_text(1, 0,
    "{{client.company}}  귀중\n"
    "담당    {{client.person}} {{client.title}}\n"
    "연락처  {{client.tel}}\n"
    "이메일  {{client.email}}\n"
    "주소    {{client.address}}")
party.set_cell_text(1, 1,
    "등록번호  {{supplier.bizNo}}\n"
    "상호      {{supplier.name}}        대표  {{supplier.ceo}}  (인)\n"
    "주소      {{supplier.address}}\n"
    "업태      {{supplier.bizType}}        종목  {{supplier.bizItem}}\n"
    "전화      {{supplier.tel}}        팩스  {{supplier.fax}}\n"
    "담당      {{supplier.manager}}  {{supplier.managerTel}}  {{supplier.email}}")
style_cell(party, 0, 0, "head", "center", BF_HEAD)
style_cell(party, 0, 1, "head", "center", BF_HEAD)
style_cell(party, 1, 0, "body", "left")
style_cell(party, 1, 1, "body", "left")
para("")

# ── 4. 관용구 + 합계금액 ─────────────────────────────────────────────────────
para("아래와 같이 견적합니다.", "body", "left")
tw = [11000, CONTENT_W - 11000]
total = table(1, 2, tw)
total.set_cell_text(0, 0, "합 계 금 액")
total.set_cell_text(0, 1, "{{totals.grandTotalText}}")
style_cell(total, 0, 0, "head", "center", BF_HEAD)
style_cell(total, 0, 1, "big", "left")
para("")

# ── 5. 항목 표 ───────────────────────────────────────────────────────────────
iw = [2600, 15400, 5800, 2600, 2200, 7000, 7400, 8024]
assert sum(iw) == CONTENT_W, sum(iw)
HEAD = ["No", "품     명", "규   격", "수량", "단위", "단  가", "금  액", "비  고"]
FIELDS = ["no", "name", "spec", "qty", "unit", "unitPrice", "amount", "note"]
ALIGN = ["center", "left", "center", "center", "center", "right", "right", "center"]
items = table(1 + MAX_ROW, 8, iw)
for c, h in enumerate(HEAD):
    items.set_cell_text(0, c, h)
    style_cell(items, 0, c, "head", "center", BF_HEAD)
for r in range(1, 1 + MAX_ROW):
    for c, f in enumerate(FIELDS):
        items.set_cell_text(r, c, "{{row.%s}}" % f)
        style_cell(items, r, c, "body", ALIGN[c])
para("")

# ── 6. 집계 표 (테두리 없는 여백 + 라벨/금액) ────────────────────────────────
sw = [CONTENT_W - 20000, 10000, 10000]
summ = table(MAX_SUM, 3, sw)
for r in range(MAX_SUM):
    summ.set_cell_text(r, 0, "")
    summ.set_cell_text(r, 1, "{{sum.label}}")
    summ.set_cell_text(r, 2, "{{sum.amount}}")
    style_cell(summ, r, 0, "body", "left", BF_NONE)
    style_cell(summ, r, 1, "body", "right")
    style_cell(summ, r, 2, "body", "right")
para("")

# ── 7. 특이사항 표 ───────────────────────────────────────────────────────────
fw = [10000, CONTENT_W - 10000]
info = table(1 + MAX_INFO, 2, fw)
info.set_cell_text(0, 0, "특 이 사 항")
info.set_cell_text(0, 1, "")
style_cell(info, 0, 0, "head", "center", BF_HEAD)
style_cell(info, 0, 1, "head", "center", BF_HEAD)
for r in range(1, 1 + MAX_INFO):
    info.set_cell_text(r, 0, "{{info.label}}")
    info.set_cell_text(r, 1, "{{info.value}}")
    style_cell(info, r, 0, "small", "center")
    style_cell(info, r, 1, "body", "left")
para("")

# ── 8. 거래 조건 표 (테두리 없음) ────────────────────────────────────────────
para("거래 조건", "head", "left")
cw = [3000, CONTENT_W - 3000]
terms = table(MAX_TERM, 2, cw)
for r in range(MAX_TERM):
    terms.set_cell_text(r, 0, "{{term.no}}.")
    terms.set_cell_text(r, 1, "{{term.text}}")
    style_cell(terms, r, 0, "body", "right", BF_NONE)
    style_cell(terms, r, 1, "body", "left", BF_NONE)
para("")

# ── 9. 비고 ──────────────────────────────────────────────────────────────────
para("비고    {{notes}}", "body", "left")

# ── 저장 — 복제한 paraPr 를 헤더에 반영해야 하므로 zip 을 다시 쓴다 ──────────
raw = doc.to_bytes()
src = zipfile.ZipFile(io.BytesIO(raw))
buf = io.BytesIO()
with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as out:
    zi = zipfile.ZipInfo("mimetype")
    zi.compress_type = zipfile.ZIP_STORED
    out.writestr(zi, src.read("mimetype"))
    for name in src.namelist():
        if name == "mimetype":
            continue
        data = header_xml.encode("utf-8") if name == "Contents/header.xml" else src.read(name)
        out.writestr(name, data)
open(OUT, "wb").write(buf.getvalue())
print("\nsaved:", OUT, len(buf.getvalue()), "bytes")
