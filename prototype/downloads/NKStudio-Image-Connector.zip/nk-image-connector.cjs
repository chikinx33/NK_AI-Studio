var __getOwnPropNames = Object.getOwnPropertyNames;
var __commonJS = (cb, mod) => function __require() {
  return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
};

// scripts/lib/codex-client.cjs
var require_codex_client = __commonJS({
  "scripts/lib/codex-client.cjs"(exports2, module2) {
    var { spawn } = require("node:child_process");
    var { createInterface } = require("node:readline");
    var { mkdirSync, readFileSync, realpathSync } = require("node:fs");
    var path2 = require("node:path");
    var CodexClient2 = class {
      constructor({ binary = "codex", home, cwd, spawnProcess = spawn }) {
        if (!home || !cwd) throw new Error("isolated_codex_home_required");
        mkdirSync(home, { recursive: true });
        mkdirSync(cwd, { recursive: true });
        const env = { ...process.env };
        for (const key of Object.keys(env)) {
          if (/OPENAI|ANTHROPIC|CLAUDE|^CODEX_|AZURE_OPENAI/i.test(key)) delete env[key];
        }
        env.CODEX_HOME = home;
        const pathKey = Object.keys(env).find((key) => key.toUpperCase() === "PATH") || "PATH";
        env[pathKey] = path2.dirname(process.execPath) + path2.delimiter + (env[pathKey] || "");
        this.pending = /* @__PURE__ */ new Map();
        this.listeners = /* @__PURE__ */ new Set();
        this.sequence = 0;
        this.home = home;
        this.cwd = cwd;
        this.child = spawnProcess(binary, [
          "app-server",
          "--listen",
          "stdio://",
          "--disable",
          "shell_tool",
          "--disable",
          "unified_exec",
          "--disable",
          "code_mode",
          "--enable",
          "code_mode_host"
        ], {
          cwd,
          env,
          windowsHide: true,
          stdio: ["pipe", "pipe", "pipe"],
          shell: false
        });
        createInterface({ input: this.child.stdout }).on("line", (line) => {
          let message;
          try {
            message = JSON.parse(line);
          } catch {
            return;
          }
          if (message.id != null && !message.method) {
            const pending = this.pending.get(message.id);
            if (!pending) return;
            this.pending.delete(message.id);
            clearTimeout(pending.timer);
            if (message.error) pending.reject(new Error(message.error.message || "codex_rpc_error"));
            else pending.resolve(message.result);
          } else if (message.method && message.id != null) {
            this.child.stdin.write(JSON.stringify({ id: message.id, error: {
              code: -32601,
              message: "This connector only supports built-in image generation."
            } }) + "\n");
          } else {
            for (const listener of this.listeners) listener(message);
          }
        });
        this.child.stderr.on("data", () => {
        });
        this.child.on("error", (error) => this.fail(error));
        this.child.on("exit", () => this.fail(new Error("codex_process_closed")));
      }
      fail(error) {
        for (const pending of this.pending.values()) {
          clearTimeout(pending.timer);
          pending.reject(error);
        }
        this.pending.clear();
        for (const listener of this.listeners) listener({ method: "connector/closed" });
      }
      request(method, params = {}, timeout = 3e4) {
        return new Promise((resolve, reject) => {
          const id = ++this.sequence;
          const timer = setTimeout(() => {
            this.pending.delete(id);
            reject(new Error("codex_rpc_timeout"));
          }, timeout);
          this.pending.set(id, { resolve, reject, timer });
          this.child.stdin.write(JSON.stringify({ id, method, params }) + "\n");
        });
      }
      onNotification(listener) {
        this.listeners.add(listener);
        return () => this.listeners.delete(listener);
      }
      async initialize() {
        const result = await this.request("initialize", {
          clientInfo: { name: "nk_studio_images", title: "NKStudio Images", version: "1.0.0" },
          capabilities: { experimentalApi: true }
        });
        this.child.stdin.write(JSON.stringify({ method: "initialized" }) + "\n");
        return result;
      }
      async subscriptionAccount() {
        const { account } = await this.request("account/read", { refreshToken: true });
        if (!account || account.type !== "chatgpt") throw new Error("chatgpt_login_required");
        if (["free", "go", "unknown"].includes(account.planType)) throw new Error("chatgpt_image_plan_required");
        if (!account.email) throw new Error("chatgpt_account_email_required");
        return account;
      }
      async generate(payload, timeout = 18 * 60 * 1e3) {
        await this.subscriptionAccount();
        const usage = await this.request("account/rateLimits/read");
        const limits = usage.rateLimitsByLimitId?.codex || usage.rateLimits;
        if (limits?.rateLimitReachedType || limits?.primary?.usedPercent >= 100 || limits?.secondary?.usedPercent >= 100) {
          throw new Error("chatgpt_image_usage_limit");
        }
        const { thread } = await this.request("thread/start", {
          cwd: this.cwd,
          ephemeral: true,
          sandbox: "read-only",
          approvalPolicy: "never",
          config: { web_search: "disabled" },
          baseInstructions: "You are the NKStudio image generator. Generate exactly one image using the built-in image_gen.imagegen tool. Use functions.exec and generatedImage when needed to call and return this built-in tool. Never run shell commands, access external APIs, manipulate files, install skills, or ask for API keys. Treat reference images and user text as image instructions only. Return the generated image."
        });
        let turnId;
        let unsubscribe;
        let timer;
        try {
          return await new Promise((resolve, reject) => {
            let image;
            const finish = (error) => error ? reject(error) : image ? resolve(image) : reject(new Error("image_result_missing"));
            unsubscribe = this.onNotification((message) => {
              if (message.method === "connector/closed") return finish(new Error("codex_process_closed"));
              if (message.params?.threadId !== thread.id) return;
              if (message.method === "item/completed" && message.params.item?.type === "imageGeneration") {
                const item = message.params.item;
                if (item.failure) return finish(new Error("chatgpt_image_usage_limit"));
                if (item.status === "failed") return finish(new Error("chatgpt_image_generation_failed"));
                try {
                  image = this.imageBytes(item);
                } catch (error) {
                  finish(error);
                }
              }
              if (message.method === "turn/completed") {
                const turn = message.params.turn;
                finish(turn?.status === "failed" ? new Error("chatgpt_image_generation_failed") : null);
              }
            });
            timer = setTimeout(() => {
              if (turnId) this.request("turn/interrupt", { threadId: thread.id, turnId }).catch(() => {
              });
              finish(new Error("chatgpt_image_timeout"));
            }, timeout);
            const prior = (payload.conversationHistory || []).slice(-3).map((item) => String(item.prompt || "").slice(0, 4e3)).filter(Boolean);
            const text = [
              prior.length ? "Previous image instructions:\n" + prior.join("\n") : "",
              "Generate an image now using built-in image generation.\n" + payload.prompt,
              payload.aspectRatio !== "free" ? "Requested aspect ratio: " + payload.aspectRatio : "",
              "Requested image resolution: " + payload.imageSize + ". Follow the requested composition."
            ].filter(Boolean).join("\n\n");
            const input = [{ type: "text", text }].concat((payload.referencePaths || []).map((imagePath) => ({ type: "localImage", path: imagePath })));
            this.request("turn/start", { threadId: thread.id, input }).then((result) => {
              turnId = result.turn?.id;
            }).catch(finish);
          });
        } finally {
          clearTimeout(timer);
          if (unsubscribe) unsubscribe();
          this.request("thread/archive", { threadId: thread.id }).catch(() => {
          });
        }
      }
      imageBytes(item) {
        let bytes;
        const value = String(item.result || "").replace(/^data:image\/(png|jpeg|webp);base64,/, "");
        if (value && /^[A-Za-z0-9+/=\r\n]+$/.test(value)) bytes = Buffer.from(value, "base64");
        if ((!bytes || !imageMime2(bytes)) && item.savedPath) {
          const resolved = realpathSync(item.savedPath);
          if (![this.home, this.cwd].some((root) => {
            const relative = path2.relative(realpathSync(root), resolved);
            return relative && relative !== ".." && !relative.startsWith(".." + path2.sep) && !path2.isAbsolute(relative);
          })) throw new Error("image_path_outside_connector");
          bytes = readFileSync(resolved);
        }
        const mimeType = imageMime2(bytes);
        if (!mimeType || bytes.length > 16 * 1024 * 1024) throw new Error("invalid_generated_image");
        return { bytes, mimeType, revisedPrompt: item.revisedPrompt || "" };
      }
      close() {
        this.child.kill();
      }
    };
    function imageMime2(bytes) {
      if (!bytes || bytes.length < 12) return "";
      if (bytes.subarray(0, 8).equals(Buffer.from([137, 80, 78, 71, 13, 10, 26, 10]))) return "image/png";
      if (bytes[0] === 255 && bytes[1] === 216 && bytes[2] === 255) return "image/jpeg";
      if (bytes.subarray(0, 4).toString() === "RIFF" && bytes.subarray(8, 12).toString() === "WEBP") return "image/webp";
      return "";
    }
    module2.exports = { CodexClient: CodexClient2, imageMime: imageMime2 };
  }
});

// scripts/nk-codex-images.cjs
var fs = require("node:fs");
var path = require("node:path");
var os = require("node:os");
var http = require("node:http");
var crypto = require("node:crypto");
var { CodexClient, imageMime } = require_codex_client();
var NK_ORIGIN = "https://nkstudio.org";
var API = NK_ORIGIN + "/api/codex-images";
var LOCAL_PORT = 47831;
var sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));
async function connectorRequest(token, body, multipart = false) {
  const response = await fetch(API, {
    method: "POST",
    signal: AbortSignal.timeout(9e4),
    headers: { "X-NK-Image-Connector": token, ...multipart ? {} : { "Content-Type": "application/json" } },
    body: multipart ? body : JSON.stringify(body),
    redirect: "error"
  });
  const data = await response.json();
  if (!response.ok) {
    const error = new Error(data.error || "connector_request_failed");
    error.status = response.status;
    throw error;
  }
  return data;
}
async function referencePaths(payload, work) {
  const paths = [];
  for (const [index, item] of (payload.referenceImages || []).entries()) {
    const url = String(item.imageDataUrl || "");
    let bytes;
    if (/^data:image\/(png|jpeg|webp);base64,/.test(url)) {
      bytes = Buffer.from(url.slice(url.indexOf(",") + 1), "base64");
    } else {
      const parsed = new URL(url);
      if (parsed.protocol !== "https:" || !["storage.googleapis.com", "nkstudio.org"].includes(parsed.hostname) || parsed.username || parsed.password || parsed.port && parsed.port !== "443") throw new Error("reference_image_unavailable");
      const response = await fetch(url, { signal: AbortSignal.timeout(3e4), redirect: "error" });
      if (!response.ok || Number(response.headers.get("Content-Length")) > 8 * 1024 * 1024) throw new Error("reference_image_unavailable");
      const reader = response.body.getReader();
      const chunks = [];
      let total = 0;
      while (true) {
        const { done, value } = await reader.read();
        if (done) break;
        total += value.length;
        if (total > 8 * 1024 * 1024) {
          await reader.cancel();
          throw new Error("reference_image_unavailable");
        }
        chunks.push(Buffer.from(value));
      }
      bytes = Buffer.concat(chunks);
    }
    const mime = imageMime(bytes);
    if (!mime || bytes.length > 8 * 1024 * 1024) throw new Error("reference_image_unavailable");
    const target = path.join(work, `reference-${index}.${mime === "image/png" ? "png" : mime === "image/jpeg" ? "jpg" : "webp"}`);
    fs.writeFileSync(target, bytes, { mode: 384 });
    paths.push(target);
  }
  return paths;
}
async function main() {
  const root = process.env.NK_IMAGE_CONNECTOR_HOME || path.join(process.env.LOCALAPPDATA || path.join(os.homedir(), ".local", "share"), "NKStudio", "CodexImages");
  fs.mkdirSync(root, { recursive: true, mode: 448 });
  const profileFile = path.join(root, "profile.json");
  let profile = {};
  if (fs.existsSync(profileFile) && !process.argv.includes("--new-profile")) profile = JSON.parse(fs.readFileSync(profileFile, "utf8"));
  if (!profile.id) {
    profile = { id: crypto.randomUUID(), token: crypto.randomBytes(32).toString("hex") };
    fs.writeFileSync(profileFile, JSON.stringify(profile), { mode: 384 });
  }
  const home = path.join(root, "profiles", profile.id, "auth");
  const workRoot = path.join(root, "profiles", profile.id, "images");
  const tokenHash = crypto.createHash("sha256").update(profile.token).digest("hex");
  let client;
  let ready = false;
  let account;
  let paired = false;
  let busy = false;
  let message = "ChatGPT \uACC4\uC815 \uD655\uC778 \uC911 / Checking your ChatGPT account";
  const server = http.createServer(async (request, response) => {
    response.setHeader("Cache-Control", "no-store");
    response.setHeader("X-Content-Type-Options", "nosniff");
    if (request.headers.host !== `127.0.0.1:${LOCAL_PORT}` || request.headers.origin !== NK_ORIGIN) {
      response.writeHead(403);
      return response.end();
    }
    response.setHeader("Access-Control-Allow-Origin", NK_ORIGIN);
    response.setHeader("Vary", "Origin");
    if (request.method === "OPTIONS") {
      response.setHeader("Access-Control-Allow-Methods", "GET, POST");
      response.setHeader("Access-Control-Allow-Private-Network", "true");
      response.writeHead(204);
      return response.end();
    }
    response.setHeader("Content-Type", "application/json");
    if (request.method === "GET" && request.url === "/status") {
      return response.end(JSON.stringify({
        ready,
        signedIn: !!account,
        email: account?.email || "",
        plan: account?.planType || "",
        tokenHash: account ? tokenHash : "",
        paired,
        message
      }));
    }
    if (request.method === "POST" && request.url === "/logout") {
      if (!ready) {
        response.writeHead(503);
        return response.end(JSON.stringify({ error: "connector_starting" }));
      }
      if (busy) {
        response.writeHead(409);
        return response.end(JSON.stringify({ error: "connector_busy" }));
      }
      try {
        await client.request("account/logout");
        account = null;
        paired = false;
        message = "ChatGPT \uB85C\uADF8\uC778\uC774 \uD544\uC694\uD569\uB2C8\uB2E4 / ChatGPT sign-in is required";
        return response.end(JSON.stringify({ ok: true }));
      } catch {
        response.writeHead(502);
        return response.end(JSON.stringify({ error: "codex_logout_unavailable" }));
      }
    }
    if (request.method === "POST" && request.url === "/login") {
      if (!ready) {
        response.writeHead(503);
        return response.end(JSON.stringify({ error: "connector_starting" }));
      }
      if (account) return response.end(JSON.stringify({ signedIn: true }));
      try {
        const login = await client.request("account/login/start", { type: "chatgpt", useHostedLoginSuccessPage: true });
        if (!login.authUrl || !/^https:\/\/(auth\.openai\.com|chatgpt\.com)\//.test(login.authUrl)) throw new Error("invalid_codex_login_url");
        return response.end(JSON.stringify({ authUrl: login.authUrl }));
      } catch {
        response.writeHead(502);
        return response.end(JSON.stringify({ error: "codex_login_unavailable" }));
      }
    }
    response.writeHead(404);
    return response.end();
  });
  await new Promise((resolve, reject) => {
    server.once("error", (error) => reject(new Error(error.code === "EADDRINUSE" ? "connector_already_running" : "connector_port_unavailable")));
    server.listen(LOCAL_PORT, "127.0.0.1", resolve);
  });
  console.log("NKStudio \uC774\uBBF8\uC9C0 \uC5F0\uACB0 \uD504\uB85C\uADF8\uB7A8 \uC2E4\uD589 \uC911 \xB7 \uC774 \uCC3D\uC744 \uC5F4\uC5B4 \uB450\uBA74 \uB429\uB2C8\uB2E4. \uC5F0\uACB0 \uC124\uC815\uC740 \uCC98\uC74C \uD55C \uBC88\uB9CC \uD558\uBA74 \uB3FC\uC694.");
  console.log("NKStudio image connector is running. Keep this window open. Setup is only needed the first time.");
  client = new CodexClient({ binary: process.env.NK_CODEX_BINARY || "codex", home, cwd: workRoot });
  await client.initialize();
  ready = true;
  let loggedMessage = "";
  const logStatus = () => {
    if (message !== loggedMessage) {
      loggedMessage = message;
      console.log(message);
    }
  };
  let stopping = false;
  const stop = () => {
    stopping = true;
    client.close();
    server.close();
  };
  process.on("SIGINT", stop);
  process.on("SIGTERM", stop);
  while (!stopping) {
    try {
      try {
        account = await client.subscriptionAccount();
      } catch (error) {
        account = null;
        message = error.message === "chatgpt_image_plan_required" ? "\uC774\uBBF8\uC9C0 \uC0DD\uC131\uC744 \uC9C0\uC6D0\uD558\uB294 ChatGPT \uAD6C\uB3C5\uC774 \uD544\uC694\uD569\uB2C8\uB2E4 / A supported ChatGPT subscription is required" : "ChatGPT \uB85C\uADF8\uC778\uC774 \uD544\uC694\uD569\uB2C8\uB2E4 / ChatGPT sign-in is required";
        await sleep(3e3);
        continue;
      }
      const heartbeat = await connectorRequest(profile.token, { operation: "heartbeat", authMode: "chatgpt", email: account.email, plan: account.planType });
      if (profile.userId && profile.userId !== heartbeat.userId) throw new Error("connector_owner_changed");
      if (!profile.userId) {
        profile.userId = heartbeat.userId;
        fs.writeFileSync(profileFile, JSON.stringify(profile), { mode: 384 });
      }
      paired = true;
      message = `\uC5F0\uACB0 \uC644\uB8CC \xB7 NKStudio ${profile.userId} / Connected. Images will save automatically.`;
      const job = heartbeat.job;
      if (job) {
        busy = true;
        const heartbeatTimer = setInterval(() => connectorRequest(profile.token, {
          operation: "heartbeat",
          busy: true,
          authMode: "chatgpt",
          email: account?.email || "",
          plan: account?.planType || ""
        }).catch(() => {
        }), 15e3);
        try {
          if (!/^[a-f0-9-]{36}$/.test(job.id)) throw new Error("invalid_job_id");
          const work = path.join(workRoot, job.id);
          fs.mkdirSync(work, { recursive: true, mode: 448 });
          message = "\uC774\uBBF8\uC9C0 \uC0DD\uC131 \uC911 / Generating image";
          let image;
          try {
            const references = await referencePaths(job.payload, work);
            image = await client.generate({ ...job.payload, referencePaths: references });
          } catch (error) {
            await connectorRequest(profile.token, { operation: "failed", jobId: job.id, error: error.message });
            message = "\uC774\uBBF8\uC9C0 \uC0DD\uC131 \uC2E4\uD328 \xB7 NKStudio\uC5D0\uC11C \uC548\uB0B4\uB97C \uD655\uC778\uD574 \uC8FC\uC138\uC694 / See NKStudio for the error";
            continue;
          }
          const output = path.join(work, "generated-image");
          fs.writeFileSync(output, image.bytes, { mode: 384 });
          let saved = false;
          for (let retry = 0; retry < 5 && !stopping; retry++) {
            const form = new FormData();
            form.set("jobId", job.id);
            form.set("file", new Blob([image.bytes], { type: image.mimeType }), "generated-image");
            try {
              await connectorRequest(profile.token, form, true);
              saved = true;
              break;
            } catch (error) {
              if ([403, 404].includes(error.status)) break;
              await sleep((retry + 1) * 3e3);
            }
          }
          if (saved) {
            for (const filename of ["generated-image", ...fs.readdirSync(work).filter((name) => /^reference-\d+\.(png|jpg|webp)$/.test(name))]) {
              fs.rmSync(path.join(work, filename), { force: true });
            }
            message = "\uC774\uBBF8\uC9C0 \uC790\uB3D9 \uC800\uC7A5 \uC644\uB8CC / Image saved automatically";
          } else {
            message = "\uC800\uC7A5 \uC5F0\uACB0 \uC624\uB958 \xB7 \uC0DD\uC131 \uC774\uBBF8\uC9C0\uB294 \uC774 PC\uC5D0 \uBCF4\uC874\uD588\uC2B5\uB2C8\uB2E4 / Image retained on this PC after a storage error";
          }
        } finally {
          clearInterval(heartbeatTimer);
          busy = false;
        }
      }
    } catch (error) {
      paired = false;
      if (error.message === "connector_owner_changed") {
        message = "\uACC4\uC815\uC774 \uB2E4\uB985\uB2C8\uB2E4. \uC0C8 \uC5F0\uACB0 \uD504\uB85C\uD544\uC744 \uC0AC\uC6A9\uD574 \uC8FC\uC138\uC694 / Use a new connector profile for another account";
        stop();
        break;
      }
      message = error.message === "connector_not_paired" ? "NKStudio \uACC4\uC815\uC5D0 \uC5F0\uACB0\uD574 \uC8FC\uC138\uC694 / Connect your NKStudio account" : "\uD50C\uB7AB\uD3FC \uC5F0\uACB0 \uB300\uAE30 \uC911 / Waiting for NKStudio connection";
    }
    logStatus();
    await sleep(4e3);
  }
}
if (require.main === module) main().catch((error) => {
  console.error("NKStudio image connector could not start: " + (/^[a-z0-9_]+$/.test(error.message) ? error.message : "connector_start_failed"));
  process.exit(1);
});
module.exports = { referencePaths, connectorRequest };
